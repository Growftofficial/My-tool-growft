import React from 'react'
import { Link } from 'react-router-dom'

import Script from 'dangerous-html/react'
import { Helmet } from 'react-helmet'

import Feature from '../components/feature'
import Offer from '../components/offer'
import Location from '../components/location'
import Guide from '../components/guide'
import Article from '../components/article'
import './home.css'

const Home = (props) => {
  return (
    <div className="home-container1">
      <Helmet>
        <title>Traveler template</title>
        <meta property="og:title" content="Traveler template" />
        <link
          rel="canonical"
          href="https://traveler-template-7lhzp2.teleporthq.app/"
        />
      </Helmet>
      <section className="home-thq-hero-elm">
        <div className="home-thq-main-elm1">
          <div className="home-thq-video-elm">
            <video
              src
              poster="/Videos/hero-cover1-1500h.png"
              className="home-video1"
            ></video>
            <div className="home-thq-tint-elm1"></div>
          </div>
          <div className="home-thq-content-elm10">
            <header className="home-thq-header-elm10">
              <header data-thq="thq-navbar" className="home-thq-navbar-elm">
                <img
                  alt="logo"
                  src="/logo.svg"
                  className="home-thq-logo-elm1"
                />
                <div data-thq="thq-burger-menu" className="home-thq-menu-elm">
                  <div className="home-thq-links-elm1">
                    <a href="#features" className="home-link1 link">
                      Features
                    </a>
                    <span className="link">How it works</span>
                    <span className="link">Prices</span>
                    <a href="#find" className="home-link2 link">
                      Contact
                    </a>
                  </div>
                  <button className="home-thq-hamburger-elm button">
                    <svg viewBox="0 0 1024 1024" className="home-icon10">
                      <path d="M128 554.667h768c23.552 0 42.667-19.115 42.667-42.667s-19.115-42.667-42.667-42.667h-768c-23.552 0-42.667 19.115-42.667 42.667s19.115 42.667 42.667 42.667zM128 298.667h768c23.552 0 42.667-19.115 42.667-42.667s-19.115-42.667-42.667-42.667h-768c-23.552 0-42.667 19.115-42.667 42.667s19.115 42.667 42.667 42.667zM128 810.667h768c23.552 0 42.667-19.115 42.667-42.667s-19.115-42.667-42.667-42.667h-768c-23.552 0-42.667 19.115-42.667 42.667s19.115 42.667 42.667 42.667z"></path>
                    </svg>
                  </button>
                </div>
                <div
                  data-thq="thq-mobile-menu"
                  className="home-thq-mobile-menu-elm"
                >
                  <div
                    data-thq="thq-mobile-menu-nav"
                    data-role="Nav"
                    className="home-thq-nav-elm1"
                  >
                    <div className="home-thq-container-elm">
                      <img
                        alt="logo"
                        src="/logo.svg"
                        className="home-thq-logo-elm2"
                      />
                      <div
                        data-thq="thq-close-menu"
                        className="home-thq-menu-close-elm"
                      >
                        <svg viewBox="0 0 1024 1024" className="home-icon12">
                          <path d="M810 274l-238 238 238 238-60 60-238-238-238 238-60-60 238-238-238-238 60-60 238 238 238-238z"></path>
                        </svg>
                      </div>
                    </div>
                    <nav
                      data-thq="thq-mobile-menu-nav-links"
                      data-role="Nav"
                      className="home-thq-nav-elm2"
                    >
                      <span className="home-text12">About</span>
                      <span className="home-text13">Features</span>
                      <span className="home-text14">Pricing</span>
                      <span className="home-text15">Team</span>
                      <span className="home-text16">Blog</span>
                    </nav>
                    <div className="home-container2">
                      <button className="home-thq-login-elm button">
                        Login
                      </button>
                      <button className="button">Register</button>
                    </div>
                  </div>
                  <div className="home-thq-icon-group-elm">
                    <svg
                      viewBox="0 0 950.8571428571428 1024"
                      className="home-icon14"
                    >
                      <path d="M925.714 233.143c-25.143 36.571-56.571 69.143-92.571 95.429 0.571 8 0.571 16 0.571 24 0 244-185.714 525.143-525.143 525.143-104.571 0-201.714-30.286-283.429-82.857 14.857 1.714 29.143 2.286 44.571 2.286 86.286 0 165.714-29.143 229.143-78.857-81.143-1.714-149.143-54.857-172.571-128 11.429 1.714 22.857 2.857 34.857 2.857 16.571 0 33.143-2.286 48.571-6.286-84.571-17.143-148-91.429-148-181.143v-2.286c24.571 13.714 53.143 22.286 83.429 23.429-49.714-33.143-82.286-89.714-82.286-153.714 0-34.286 9.143-65.714 25.143-93.143 90.857 112 227.429 185.143 380.571 193.143-2.857-13.714-4.571-28-4.571-42.286 0-101.714 82.286-184.571 184.571-184.571 53.143 0 101.143 22.286 134.857 58.286 41.714-8 81.714-23.429 117.143-44.571-13.714 42.857-42.857 78.857-81.143 101.714 37.143-4 73.143-14.286 106.286-28.571z"></path>
                    </svg>
                    <svg
                      viewBox="0 0 877.7142857142857 1024"
                      className="home-icon16"
                    >
                      <path d="M585.143 512c0-80.571-65.714-146.286-146.286-146.286s-146.286 65.714-146.286 146.286 65.714 146.286 146.286 146.286 146.286-65.714 146.286-146.286zM664 512c0 124.571-100.571 225.143-225.143 225.143s-225.143-100.571-225.143-225.143 100.571-225.143 225.143-225.143 225.143 100.571 225.143 225.143zM725.714 277.714c0 29.143-23.429 52.571-52.571 52.571s-52.571-23.429-52.571-52.571 23.429-52.571 52.571-52.571 52.571 23.429 52.571 52.571zM438.857 152c-64 0-201.143-5.143-258.857 17.714-20 8-34.857 17.714-50.286 33.143s-25.143 30.286-33.143 50.286c-22.857 57.714-17.714 194.857-17.714 258.857s-5.143 201.143 17.714 258.857c8 20 17.714 34.857 33.143 50.286s30.286 25.143 50.286 33.143c57.714 22.857 194.857 17.714 258.857 17.714s201.143 5.143 258.857-17.714c20-8 34.857-17.714 50.286-33.143s25.143-30.286 33.143-50.286c22.857-57.714 17.714-194.857 17.714-258.857s5.143-201.143-17.714-258.857c-8-20-17.714-34.857-33.143-50.286s-30.286-25.143-50.286-33.143c-57.714-22.857-194.857-17.714-258.857-17.714zM877.714 512c0 60.571 0.571 120.571-2.857 181.143-3.429 70.286-19.429 132.571-70.857 184s-113.714 67.429-184 70.857c-60.571 3.429-120.571 2.857-181.143 2.857s-120.571 0.571-181.143-2.857c-70.286-3.429-132.571-19.429-184-70.857s-67.429-113.714-70.857-184c-3.429-60.571-2.857-120.571-2.857-181.143s-0.571-120.571 2.857-181.143c3.429-70.286 19.429-132.571 70.857-184s113.714-67.429 184-70.857c60.571-3.429 120.571-2.857 181.143-2.857s120.571-0.571 181.143 2.857c70.286 3.429 132.571 19.429 184 70.857s67.429 113.714 70.857 184c3.429 60.571 2.857 120.571 2.857 181.143z"></path>
                    </svg>
                    <svg
                      viewBox="0 0 602.2582857142856 1024"
                      className="home-icon18"
                    >
                      <path d="M548 6.857v150.857h-89.714c-70.286 0-83.429 33.714-83.429 82.286v108h167.429l-22.286 169.143h-145.143v433.714h-174.857v-433.714h-145.714v-169.143h145.714v-124.571c0-144.571 88.571-223.429 217.714-223.429 61.714 0 114.857 4.571 130.286 6.857z"></path>
                    </svg>
                  </div>
                </div>
              </header>
            </header>
            <div className="home-thq-center-elm">
              <div className="home-thq-heading-elm10">
                <h1 className="home-thq-header-elm11">
                  See the world like a local
                </h1>
                <p className="home-thq-caption-elm10">
                  Find a local guide consectetur adipiscing elit, sed do eiusmod
                  tempor incididunt.
                </p>
              </div>
              <div className="home-thq-border-elm">
                <div className="home-thq-filter-elm">
                  <img
                    alt="image"
                    src="/Icons/location.svg"
                    className="home-image1"
                  />
                  <input
                    type="text"
                    placeholder="Destination"
                    className="home-textinput1 input"
                  />
                  <input
                    type="date"
                    placeholder="Date"
                    className="home-textinput2 input"
                  />
                  <input
                    type="number"
                    placeholder="Group size"
                    className="home-textinput3 input"
                  />
                  <div className="home-thq-search-elm">
                    <img
                      alt="image"
                      src="/Icons/search.svg"
                      className="home-thq-icon-elm"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div id="features" className="home-thq-feaures-elm">
          <div className="home-thq-content-elm11">
            <Feature></Feature>
            <Feature icon="/Icons/headset.svg" header="24/7 Support"></Feature>
            <Feature icon="/Icons/person.svg" header="Private Tours"></Feature>
          </div>
        </div>
      </section>
      <section id="tours" className="home-thq-quick-view-elm">
        <div className="home-thq-main-elm2">
          <div className="home-thq-heading-elm11">
            <h2 className="home-thq-header-elm12">
              See the world like a local
            </h2>
            <p className="home-thq-caption-elm11">
              Lorem ipsum dolor sit consectetur adipiscing elit, sed do eiusmod
              tempor incididunt.
            </p>
          </div>
          <div className="home-thq-sorting-elm">
            <button className="home-thq-option-primary-elm button">All</button>
            <button className="button-option button">Popular</button>
            <button className="button-option button">Featured</button>
            <button className="button-option button">Trending</button>
          </div>
        </div>
        <div className="home-thq-offers-elm">
          <Link to="/">
            <div className="home-thq-offer-container-elm1">
              <Offer image="/Offers/offers-11-1500w.png"></Offer>
            </div>
          </Link>
          <Link to="/">
            <div className="home-thq-offer-container-elm2">
              <Offer
                image="/Offers/offers-21-1500w.png"
                guides="54 Local guides"
                location="Barcelona, Spain"
              ></Offer>
            </div>
          </Link>
          <Link to="/">
            <div className="home-thq-offer-container-elm3">
              <Offer
                image="/Offers/offers-31-1500w.png"
                guides="34 Local Guides"
                location="Machu Picchu, Peru"
              ></Offer>
            </div>
          </Link>
          <Link to="/">
            <div className="home-thq-offer-container-elm4">
              <Offer
                image="/Offers/offers-41-1500w.png"
                guides="1 Local guide"
                location="Doha, Quatar"
              ></Offer>
            </div>
          </Link>
          <Link to="/">
            <div className="home-thq-offer-container-elm5">
              <Offer
                image="/Offers/offers-51-1500w.png"
                guides="6 Local guides"
                location="Rhodes, Greece"
              ></Offer>
            </div>
          </Link>
          <Link to="/">
            <div className="home-thq-offer-container-elm6">
              <Offer
                image="/Offers/offers-61-1500w.png"
                guides="132 Local guides"
                location="New York, USA"
              ></Offer>
            </div>
          </Link>
          <Link to="/">
            <div className="home-thq-offer-container-elm7">
              <Offer
                image="/Offers/offers-71-1500w.png"
                guides="1 Local guide"
                location="Doha, Quatar"
              ></Offer>
            </div>
          </Link>
          <Link to="/">
            <div className="home-thq-offer-container-elm8">
              <Offer
                image="/Offers/offers-81-1500w.png"
                guides="6 Local guides"
                location="Rhodes, Greece"
              ></Offer>
            </div>
          </Link>
          <Link to="/">
            <div className="home-thq-offer-container-elm9">
              <Offer
                image="/Offers/offers-91-1500w.png"
                guides="132 Local guides"
                location="New York, USA"
              ></Offer>
            </div>
          </Link>
        </div>
        <div className="home-thq-pagination-elm">
          <button className="home-thq-previous-elm1 button-option button">
            <svg viewBox="0 0 1024 1024" className="home-icon20">
              <path d="M658 708l-60 60-256-256 256-256 60 60-196 196z"></path>
            </svg>
            <span className="home-text17">Previous</span>
          </button>
          <div className="home-thq-pages-elm">
            <div className="home-thq-primary-elm">
              <div className="home-thq-number-current-elm page-current page">
                <span className="home-text18">1</span>
              </div>
              <div className="page">
                <span className="home-text19">2</span>
              </div>
              <div className="page home-thq-number-elm2">
                <span className="home-text20">3</span>
              </div>
            </div>
            <img
              alt="image"
              src="/Icons/more.svg"
              className="home-thq-more-elm"
            />
            <div className="page">
              <span className="home-text21">12</span>
            </div>
          </div>
          <button className="home-thq-next-elm1 button-option button">
            <span className="home-text22">Next</span>
            <svg viewBox="0 0 1024 1024" className="home-icon22">
              <path d="M426 256l256 256-256 256-60-60 196-196-196-196z"></path>
            </svg>
          </button>
        </div>
      </section>
      <section className="home-thq-testimonials-elm">
        <div className="home-thq-content-elm12">
          <div className="home-thq-heading-elm12">
            <span className="home-thq-title-elm">Customer testimonial</span>
            <p className="home-thq-quote-elm">
              “We’ve used Traveler to lorem ipsum dolor sit amet, consectetur
              adipiscing elit, sed do eiusmod tempor incididunt ut labore et
              dolore magna aliqua.”
            </p>
          </div>
          <div className="home-thq-details-elm">
            <div className="home-thq-author-elm">
              <img
                alt="image"
                src="/Avatar/quote-200h.png"
                className="home-thq-avatar-elm"
              />
              <span className="home-thq-name-elm">Michael McDonald</span>
            </div>
            <div className="home-thq-controls-elm">
              <div className="page">
                <span className="home-text23">&lt;</span>
              </div>
              <div className="home-thq-next-elm2 page">
                <span className="home-text24">&lt;</span>
              </div>
            </div>
          </div>
        </div>
      </section>
      <section id="how-it-works" className="home-thq-highlights-elm">
        <div className="home-thq-highlight-elm1">
          <div className="home-thq-content-elm13">
            <div className="home-thq-heading-elm13">
              <h2 className="home-thq-header-elm13">
                Excepteur sint occaecat cupidatat non proident
              </h2>
              <p className="home-thq-caption-elm12">
                Lorem ipsum dolor sit consectetur adipiscing elit, sed do
                eiusmod tempor incididunt.
              </p>
            </div>
            <button className="button-arrow button">
              <span className="home-text25">Read more</span>
              <span className="home-text26">&gt;</span>
            </button>
          </div>
          <div className="home-thq-image-elm1">
            <img
              alt="image"
              src="/Highlights/highlight-1-1500w.png"
              className="home-image2"
            />
            <div className="home-thq-rectangle-elm"></div>
          </div>
        </div>
        <div className="home-thq-highlight-elm2">
          <div className="home-thq-image-elm2">
            <img
              alt="image"
              src="/Highlights/highlight-2-1500w.png"
              className="home-image3"
            />
          </div>
          <div className="home-thq-content-elm14">
            <div className="home-thq-heading-elm14">
              <h2 className="home-thq-header-elm14">
                Excepteur sint occaecat cupidatat non proident
              </h2>
              <p className="home-thq-caption-elm13">
                <span>
                  Lorem ipsum dolor sit consectetur adipiscing elit, sed do
                  eiusmod tempor incididunt.
                </span>
                <br></br>
                <br></br>
                <span>
                  Sed ut perspiciatis unde omnis iste natus error sit voluptatem
                  accusantium doloremque laudantium, totam rem aperiam, eaque
                  ipsa quae ab illo inventore veritatis et quasi architecto
                  beatae vitae dicta sunt explicabo.
                </span>
                <br></br>
              </p>
            </div>
            <button className="home-thq-find-elm1 button">
              Find a local guide
            </button>
          </div>
        </div>
      </section>
      <section id="destinations" className="home-thq-destinations-elm">
        <div className="home-thq-video-details-elm">
          <div className="home-thq-heading-elm15">
            <h2 className="home-thq-header-elm15">Spotlight destinations</h2>
            <p className="home-thq-caption-elm14">
              Lorem ipsum dolor sit consectetur adipiscing elit, sed do eiusmod
              tempor incididunt.
            </p>
          </div>
          <div className="home-thq-video-wrapper-elm">
            <div className="home-thq-tint-elm2">
              <img alt="image" src="/Icons/play.svg" className="home-image4" />
            </div>
            <video
              src
              poster="/Videos/spotlight-cover1-1500w.png"
              className="home-video2"
            ></video>
          </div>
        </div>
        <p className="home-thq-caption-elm15">
          Sed ut perspiciatis unde omnis iste natus error sit voluptatem
          accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae
          ab illo inventore veritatis et quasi architecto.
        </p>
        <div className="home-thq-list-elm1">
          <Link to="/" className="home-navlink19">
            <div className="home-thq-location-wrapper-elm1">
              <Location></Location>
            </div>
          </Link>
          <Link to="/" className="home-navlink20">
            <div className="home-thq-location-wrapper-elm2">
              <Location
                location="Paris, France"
                background="/Destinations/destination-2-400h.png"
              ></Location>
            </div>
          </Link>
          <Link to="/" className="home-navlink21">
            <div className="home-thq-location-wrapper-elm3">
              <Location
                location="Bruges, Belgium"
                background="/Destinations/destination-3-400h.png"
              ></Location>
            </div>
          </Link>
          <Link to="/" className="home-navlink22">
            <div className="home-thq-location-wrapper-elm4">
              <Location
                location="London, UK"
                background="/Destinations/destination-4-400h.png"
              ></Location>
            </div>
          </Link>
        </div>
        <button className="home-thq-find-elm2 button">
          Find a local guide
        </button>
      </section>
      <section id="guides" className="home-thq-guides-elm">
        <div className="home-thq-heading-elm16">
          <h2 className="home-thq-header-elm16">Meet our guides</h2>
          <p className="home-thq-caption-elm16">
            Lorem ipsum dolor sit consectetur adipiscing elit, sed do eiusmod
            tempor incididunt.
          </p>
        </div>
        <div className="home-thq-list-elm2">
          <Link to="/">
            <div className="home-thq-guide-wrapper-elm1">
              <Guide></Guide>
            </div>
          </Link>
          <Link to="/">
            <div className="home-thq-guide-wrapper-elm2">
              <Guide
                location="Paris, France"
                portrait="/Guides/guide-2.png"
                rootClassName="guideroot-class-name2"
              ></Guide>
            </div>
          </Link>
          <Link to="/">
            <div className="home-thq-guide-wrapper-elm3">
              <Guide
                location="Bruges, Belgium"
                portrait="/Guides/guide-3.png"
                rootClassName="guideroot-class-name"
              ></Guide>
            </div>
          </Link>
          <Link to="/">
            <div className="home-thq-guide-wrapper-elm4">
              <Guide
                location="London, UK "
                portrait="/Guides/guide-4.png"
                rootClassName="guideroot-class-name1"
              ></Guide>
            </div>
          </Link>
        </div>
      </section>
      <section className="home-thq-articles-elm">
        <div id="articles" className="home-thq-content-elm15">
          <div className="home-thq-heading-elm17">
            <h2 className="home-thq-header-elm17">
              Excepteur sint occaecat cupidatat non proident
            </h2>
            <p className="home-thq-caption-elm17">
              Lorem ipsum dolor sit consectetur adipiscing elit, sed do eiusmod
              tempor incididunt.
            </p>
          </div>
          <div className="home-thq-list-elm3">
            <div className="home-thq-row-elm1">
              <Article
                image="/Articles/articles-11-1500w.png"
                rootClassName="articleroot-class-name1"
              ></Article>
              <Article
                image="/Articles/articles-21-1500w.png"
                description="Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. "
                rootClassName="articleroot-class-name"
              ></Article>
            </div>
            <div className="home-thq-row-elm2">
              <Article
                image="/Articles/articles-31-1500w.png"
                description="Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."
                rootClassName="articleroot-class-name2"
              ></Article>
              <Article
                image="/Articles/articles-41-1500w.png"
                description="Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. "
                rootClassName="articleroot-class-name3"
              ></Article>
            </div>
            <div className="home-thq-row-elm3">
              <button className="home-thq-read-all-elm button-option button">
                Read all articles
              </button>
            </div>
          </div>
        </div>
      </section>
      <section className="home-thq-faq-elm">
        <div id="faqs" className="home-thq-content-elm16">
          <div className="home-thq-heading-elm18">
            <h2 className="home-thq-header-elm18">
              Frequently asked questions
            </h2>
            <p className="home-thq-caption-elm18">
              Lorem ipsum dolor sit consectetur adipiscing elit, sed do eiusmod
              tempor incididunt.
            </p>
          </div>
          <div className="home-thq-accordion-elm1">
            <div
              data-role="accordion-container"
              className="accordion home-thq-element-elm1"
            >
              <div className="home-thq-content-elm17">
                <span className="home-thq-header-elm19">
                  Lorem ipsum dolor sit ametetur elit?
                </span>
                <span
                  data-role="accordion-content"
                  className="home-thq-description-elm1"
                >
                  Sed ut perspiciatis unde omnis iste natus error sit voluptatem
                  accusantium doloremque laudantium, totam rem aperiam, eaque
                  ipsa quae ab illo inventore veritatis et quasi architecto
                  beatae vitae dicta sunt explicabo.
                </span>
              </div>
              <div className="home-thq-icon-container-elm1">
                <svg
                  viewBox="0 0 1024 1024"
                  data-role="accordion-icon-closed"
                  className="home-icon24"
                >
                  <path d="M213.333 554.667h256v256c0 23.552 19.115 42.667 42.667 42.667s42.667-19.115 42.667-42.667v-256h256c23.552 0 42.667-19.115 42.667-42.667s-19.115-42.667-42.667-42.667h-256v-256c0-23.552-19.115-42.667-42.667-42.667s-42.667 19.115-42.667 42.667v256h-256c-23.552 0-42.667 19.115-42.667 42.667s19.115 42.667 42.667 42.667z"></path>
                </svg>
                <svg
                  viewBox="0 0 1024 1024"
                  data-role="accordion-icon-open"
                  className="home-icon26"
                >
                  <path d="M213.333 554.667h597.333c23.552 0 42.667-19.115 42.667-42.667s-19.115-42.667-42.667-42.667h-597.333c-23.552 0-42.667 19.115-42.667 42.667s19.115 42.667 42.667 42.667z"></path>
                </svg>
              </div>
            </div>
            <div
              data-role="accordion-container"
              className="home-thq-element-elm2 accordion"
            >
              <div className="home-thq-content-elm18">
                <span className="home-thq-header-elm20">
                  Excepteur sint occaecat cupidatat non sunt in culpa qui
                  officia deserunt mollit anim id est laborum?
                </span>
                <span
                  data-role="accordion-content"
                  className="home-thq-description-elm2"
                >
                  Sed ut perspiciatis unde omnis iste natus error sit voluptatem
                  accusantium doloremque laudantium, totam rem aperiam, eaque
                  ipsa quae ab illo inventore veritatis et quasi architecto
                  beatae vitae dicta sunt explicabo.
                </span>
              </div>
              <div className="home-thq-icon-container-elm2">
                <svg
                  viewBox="0 0 1024 1024"
                  data-role="accordion-icon-closed"
                  className="home-icon28"
                >
                  <path d="M213.333 554.667h256v256c0 23.552 19.115 42.667 42.667 42.667s42.667-19.115 42.667-42.667v-256h256c23.552 0 42.667-19.115 42.667-42.667s-19.115-42.667-42.667-42.667h-256v-256c0-23.552-19.115-42.667-42.667-42.667s-42.667 19.115-42.667 42.667v256h-256c-23.552 0-42.667 19.115-42.667 42.667s19.115 42.667 42.667 42.667z"></path>
                </svg>
                <svg
                  viewBox="0 0 1024 1024"
                  data-role="accordion-icon-open"
                  className="home-icon30"
                >
                  <path d="M213.333 554.667h597.333c23.552 0 42.667-19.115 42.667-42.667s-19.115-42.667-42.667-42.667h-597.333c-23.552 0-42.667 19.115-42.667 42.667s19.115 42.667 42.667 42.667z"></path>
                </svg>
              </div>
            </div>
            <div
              data-role="accordion-container"
              className="home-thq-element-elm3 accordion"
            >
              <div className="home-thq-content-elm19">
                <span className="home-thq-header-elm21">
                  Tempor incididunt ut labore et dolore magna aliquat enim ad
                  minim?
                </span>
                <span
                  data-role="accordion-content"
                  className="home-thq-description-elm3"
                >
                  Sed ut perspiciatis unde omnis iste natus error sit voluptatem
                  accusantium doloremque laudantium, totam rem aperiam, eaque
                  ipsa quae ab illo inventore veritatis et quasi architecto
                  beatae vitae dicta sunt explicabo.
                </span>
              </div>
              <div className="home-thq-icon-container-elm3">
                <svg
                  viewBox="0 0 1024 1024"
                  data-role="accordion-icon-closed"
                  className="home-icon32"
                >
                  <path d="M213.333 554.667h256v256c0 23.552 19.115 42.667 42.667 42.667s42.667-19.115 42.667-42.667v-256h256c23.552 0 42.667-19.115 42.667-42.667s-19.115-42.667-42.667-42.667h-256v-256c0-23.552-19.115-42.667-42.667-42.667s-42.667 19.115-42.667 42.667v256h-256c-23.552 0-42.667 19.115-42.667 42.667s19.115 42.667 42.667 42.667z"></path>
                </svg>
                <svg
                  viewBox="0 0 1024 1024"
                  data-role="accordion-icon-open"
                  className="home-icon34"
                >
                  <path d="M213.333 554.667h597.333c23.552 0 42.667-19.115 42.667-42.667s-19.115-42.667-42.667-42.667h-597.333c-23.552 0-42.667 19.115-42.667 42.667s19.115 42.667 42.667 42.667z"></path>
                </svg>
              </div>
            </div>
            <div
              data-role="accordion-container"
              className="home-thq-element-elm4 accordion"
            >
              <div className="home-thq-content-elm20">
                <span className="home-thq-header-elm22">
                  Lorem ipsum dolor sit ametetur elit?
                </span>
                <span
                  data-role="accordion-content"
                  className="home-thq-description-elm4"
                >
                  Sed ut perspiciatis unde omnis iste natus error sit voluptatem
                  accusantium doloremque laudantium, totam rem aperiam, eaque
                  ipsa quae ab illo inventore veritatis et quasi architecto
                  beatae vitae dicta sunt explicabo.
                </span>
              </div>
              <div className="home-thq-icon-container-elm4">
                <svg
                  viewBox="0 0 1024 1024"
                  data-role="accordion-icon-closed"
                  className="home-icon36"
                >
                  <path d="M213.333 554.667h256v256c0 23.552 19.115 42.667 42.667 42.667s42.667-19.115 42.667-42.667v-256h256c23.552 0 42.667-19.115 42.667-42.667s-19.115-42.667-42.667-42.667h-256v-256c0-23.552-19.115-42.667-42.667-42.667s-42.667 19.115-42.667 42.667v256h-256c-23.552 0-42.667 19.115-42.667 42.667s19.115 42.667 42.667 42.667z"></path>
                </svg>
                <svg
                  viewBox="0 0 1024 1024"
                  data-role="accordion-icon-open"
                  className="home-icon38"
                >
                  <path d="M213.333 554.667h597.333c23.552 0 42.667-19.115 42.667-42.667s-19.115-42.667-42.667-42.667h-597.333c-23.552 0-42.667 19.115-42.667 42.667s19.115 42.667 42.667 42.667z"></path>
                </svg>
              </div>
            </div>
            <div
              data-role="accordion-container"
              className="home-thq-element-elm5 accordion"
            >
              <div className="home-thq-content-elm21">
                <span className="home-thq-header-elm23">
                  Incididunt ut labore et dolore?
                </span>
                <span
                  data-role="accordion-content"
                  className="home-thq-description-elm5"
                >
                  Sed ut perspiciatis unde omnis iste natus error sit voluptatem
                  accusantium doloremque laudantium, totam rem aperiam, eaque
                  ipsa quae ab illo inventore veritatis et quasi architecto
                  beatae vitae dicta sunt explicabo.
                </span>
              </div>
              <div className="home-thq-icon-container-elm5">
                <svg
                  viewBox="0 0 1024 1024"
                  data-role="accordion-icon-closed"
                  className="home-icon40"
                >
                  <path d="M213.333 554.667h256v256c0 23.552 19.115 42.667 42.667 42.667s42.667-19.115 42.667-42.667v-256h256c23.552 0 42.667-19.115 42.667-42.667s-19.115-42.667-42.667-42.667h-256v-256c0-23.552-19.115-42.667-42.667-42.667s-42.667 19.115-42.667 42.667v256h-256c-23.552 0-42.667 19.115-42.667 42.667s19.115 42.667 42.667 42.667z"></path>
                </svg>
                <svg
                  viewBox="0 0 1024 1024"
                  data-role="accordion-icon-open"
                  className="home-icon42"
                >
                  <path d="M213.333 554.667h597.333c23.552 0 42.667-19.115 42.667-42.667s-19.115-42.667-42.667-42.667h-597.333c-23.552 0-42.667 19.115-42.667 42.667s19.115 42.667 42.667 42.667z"></path>
                </svg>
              </div>
            </div>
          </div>
        </div>
      </section>
      <section id="find" className="home-thq-find-elm3">
        <div className="home-thq-heading-elm19">
          <h2 className="home-thq-header-elm24">Find a local guide now</h2>
          <p className="home-thq-caption-elm19">
            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
            eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim
            ad minim veniam.
          </p>
        </div>
        <button className="home-thq-find-elm4 button">
          Find a local guide
        </button>
      </section>
      <section className="home-thq-footer-elm">
        <div className="home-thq-content-elm22">
          <div className="home-thq-main-elm3">
            <div className="home-thq-branding-elm">
              <div className="home-thq-heading-elm20">
                <img alt="image" src="/logo.svg" className="home-image5" />
                <p className="home-thq-caption-elm20">
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed
                  do eiusmod tempor incididunt ut labore
                </p>
              </div>
            </div>
            <div className="home-thq-links-elm2">
              <div className="home-thq-items-elm1">
                <button className="home-thq-link-elm10 button button-clean">
                  Find a guide
                </button>
                <a
                  href="#destinations"
                  className="home-thq-link-elm11 button button-clean"
                >
                  Find a tour
                </a>
                <a
                  href="#destinations"
                  className="home-thq-link-elm12 button button-clean"
                >
                  Visit a city
                </a>
                <a
                  href="#destinations"
                  className="home-thq-link-elm13 button button-clean"
                >
                  Visit a country
                </a>
              </div>
              <div className="home-thq-items-elm2">
                <a
                  href="#how-it-works"
                  className="home-thq-link-elm14 button button-clean"
                >
                  How it works
                </a>
                <button className="home-thq-link-elm15 button button-clean">
                  Cancelation policy
                </button>
                <button className="home-thq-link-elm16 button button-clean">
                  Local guides
                </button>
                <button className="home-thq-link-elm17 button button-clean">
                  Affiliate
                </button>
              </div>
              <div className="home-thq-items-elm3">
                <button className="home-thq-link-elm18 button button-clean">
                  About us
                </button>
                <button className="home-thq-link-elm19 button button-clean">
                  Blog
                </button>
                <button className="home-thq-link-elm20 button button-clean">
                  Partners
                </button>
                <button className="home-thq-link-elm21 button button-clean">
                  Faqs
                </button>
                <button className="home-thq-link-elm22 button button-clean">
                  Careers
                </button>
              </div>
            </div>
          </div>
          <span className="home-thq-copyright-elm">
            © 2022 Character. All Rights Reserved.
          </span>
        </div>
      </section>
      <div>
        <div className="home-container4">
          <Script
            html={`<script>
  function initAccordion() {
    /*
    Accordion - Code Embed
    */
    const accordionContainers = document.querySelectorAll(
      '[data-role="accordion-container"]'
    ); // All accordion containers
    const accordionContents = document.querySelectorAll(
      '[data-role="accordion-content"]'
    ); // All accordion content
    const accordionIconsClosed = document.querySelectorAll(
      '[data-role="accordion-icon-closed"]'
    ); // All accordion closed icons
    const accordionIconsOpen = document.querySelectorAll(
      '[data-role="accordion-icon-open"]'
    ); // All accordion open icons

    accordionContents.forEach((accordionContent) => {
      accordionContent.style.display = "none"; //Hides all accordion contents
    });

    accordionIconsClosed.forEach((icon) => {
      icon.style.display = "flex";
    });

    accordionIconsOpen.forEach((icon) => {
      icon.style.display = "none";
    });

    accordionContainers.forEach((accordionContainer, index) => {
      if (accordionContainer.classList.contains("initialised")) {
        return;
      }

      accordionContainer.classList.add("initiased");

      accordionContainer.addEventListener("click", () => {
        if (accordionContents[index].style.display === "flex") {
          // If the accordion is already open, close it
          accordionContents[index].style.display = "none";
          accordionIconsClosed[index].style.display = "flex";
          accordionIconsOpen[index].style.display = "none";
        } else {
          // If the accordion is closed, open it
          accordionContents.forEach((accordionContent) => {
            accordionContent.style.display = "none"; //Hides all accordion contents
          });

          accordionIconsClosed.forEach((accordionIcon) => {
            accordionIcon.style.display = "flex"; // Resets all icon transforms to 0deg (default)
          });

          accordionIconsOpen.forEach((accordionIcon) => {
            accordionIcon.style.display = "none";
          });

          accordionContents[index].style.display = "flex"; // Shows accordion content
          accordionIconsClosed[index].style.display = "none"; // Rotates accordion icon 180deg
          accordionIconsOpen[index].style.display = "flex";
        }
      });
    });
  }

  initAccordion();
</script>
`}
          ></Script>
        </div>
      </div>
      <a href="https://play.teleporthq.io/signup" className="home-link3">
        <div aria-label="Sign up to TeleportHQ" className="home-container5">
          <svg
            width="24"
            height="24"
            viewBox="0 0 19 21"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
            className="home-icon44"
          >
            <path
              d="M9.1017 4.64355H2.17867C0.711684 4.64355 -0.477539 5.79975 -0.477539 7.22599V13.9567C-0.477539 15.3829 0.711684 16.5391 2.17867 16.5391H9.1017C10.5687 16.5391 11.7579 15.3829 11.7579 13.9567V7.22599C11.7579 5.79975 10.5687 4.64355 9.1017 4.64355Z"
              fill="#B23ADE"
            ></path>
            <path
              d="M10.9733 12.7878C14.4208 12.7878 17.2156 10.0706 17.2156 6.71886C17.2156 3.3671 14.4208 0.649963 10.9733 0.649963C7.52573 0.649963 4.73096 3.3671 4.73096 6.71886C4.73096 10.0706 7.52573 12.7878 10.9733 12.7878Z"
              fill="#FF5C5C"
            ></path>
            <path
              d="M17.7373 13.3654C19.1497 14.1588 19.1497 15.4634 17.7373 16.2493L10.0865 20.5387C8.67402 21.332 7.51855 20.6836 7.51855 19.0968V10.5141C7.51855 8.92916 8.67402 8.2807 10.0865 9.07221L17.7373 13.3654Z"
              fill="#2874DE"
            ></path>
          </svg>
          <span className="home-text32">Built in TeleportHQ</span>
        </div>
      </a>
    </div>
  )
}

export default Home
