import React from 'react'

import PropTypes from 'prop-types'

import './location.css'

const Location = (props) => {
  return (
    <div className="location-thq-item-elm">
      <img
        alt="image"
        src={props.background}
        className="location-thq-background-elm"
      />
      <div className="location-thq-content-elm">
        <span className="location-thq-location-elm">{props.location}</span>
      </div>
    </div>
  )
}

Location.defaultProps = {
  background: '/Destinations/destination-1-400h.png',
  location: 'Tokyo, Japan',
}

Location.propTypes = {
  background: PropTypes.string,
  location: PropTypes.string,
}

export default Location
