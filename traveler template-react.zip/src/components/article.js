import React from 'react'

import PropTypes from 'prop-types'

import './article.css'

const Article = (props) => {
  return (
    <div className={`article-thq-article-elm ${props.rootClassName} `}>
      <img alt="image" src={props.image} className="article-thq-image-elm" />
      <div className="article-thq-content-elm">
        <div className="article-thq-heading-elm">
          <h2 className="article-thq-header-elm">{props.header}</h2>
          <p className="article-thq-description-elm">{props.description}</p>
        </div>
        <button className="button-arrow button">
          <span className="article-text1">Read more</span>
          <span className="article-text2">&gt;</span>
        </button>
      </div>
    </div>
  )
}

Article.defaultProps = {
  rootClassName: '',
  image: 'https://play.teleporthq.io/static/svg/default-img.svg',
  header: 'Understand your customers',
  description:
    'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.',
}

Article.propTypes = {
  rootClassName: PropTypes.string,
  image: PropTypes.string,
  header: PropTypes.string,
  description: PropTypes.string,
}

export default Article
