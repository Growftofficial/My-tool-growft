import React from 'react'

import PropTypes from 'prop-types'

import './guide.css'

const Guide = (props) => {
  return (
    <div className={`guide-thq-guide-elm ${props.rootClassName} `}>
      <img
        alt="image"
        src={props.portrait}
        className="guide-thq-portrait-elm"
      />
      <div className="guide-thq-details-elm">
        <h3 className="guide-thq-name-elm">{props.name}</h3>
        <span className="guide-thq-location-elm">{props.location}</span>
      </div>
    </div>
  )
}

Guide.defaultProps = {
  name: 'Miura Avaron',
  rootClassName: '',
  portrait: '/Guides/guide-1.png',
  location: 'Tokyo, Japan',
}

Guide.propTypes = {
  name: PropTypes.string,
  rootClassName: PropTypes.string,
  portrait: PropTypes.string,
  location: PropTypes.string,
}

export default Guide
