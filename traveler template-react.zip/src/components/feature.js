import React from 'react'

import PropTypes from 'prop-types'

import './feature.css'

const Feature = (props) => {
  return (
    <div className="feature-thq-feature-elm">
      <div className="feature-thq-heading-elm">
        <img alt="image" src={props.icon} className="feature-thq-icon-elm" />
        <h3 className="feature-thq-header-elm">{props.header}</h3>
      </div>
      <p className="feature-thq-description-elm">{props.description}</p>
    </div>
  )
}

Feature.defaultProps = {
  description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
  icon: '/Icons/thumbs-up.svg',
  header: 'Hand Picked Guides',
}

Feature.propTypes = {
  description: PropTypes.string,
  icon: PropTypes.string,
  header: PropTypes.string,
}

export default Feature
