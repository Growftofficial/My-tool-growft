---
name: Ashraf's Scissors Hands
colors:
  surface: '#f9f9f9'
  surface-dim: '#dadada'
  surface-bright: '#f9f9f9'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f3f4'
  surface-container: '#eeeeee'
  surface-container-high: '#e8e8e8'
  surface-container-highest: '#e2e2e2'
  on-surface: '#1a1c1c'
  on-surface-variant: '#504442'
  inverse-surface: '#2f3131'
  inverse-on-surface: '#f0f1f1'
  outline: '#827472'
  outline-variant: '#d3c3c0'
  surface-tint: '#745853'
  primary: '#271310'
  on-primary: '#ffffff'
  primary-container: '#3e2723'
  on-primary-container: '#ae8d87'
  inverse-primary: '#e3beb8'
  secondary: '#7c5730'
  on-secondary: '#ffffff'
  secondary-container: '#fdcb9b'
  on-secondary-container: '#79542d'
  tertiary: '#191817'
  on-tertiary: '#ffffff'
  tertiary-container: '#2e2d2b'
  on-tertiary-container: '#969491'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdad4'
  primary-fixed-dim: '#e3beb8'
  on-primary-fixed: '#2b1613'
  on-primary-fixed-variant: '#5b403c'
  secondary-fixed: '#ffdcbd'
  secondary-fixed-dim: '#eebd8e'
  on-secondary-fixed: '#2c1600'
  on-secondary-fixed-variant: '#61401b'
  tertiary-fixed: '#e5e2df'
  tertiary-fixed-dim: '#c9c6c3'
  on-tertiary-fixed: '#1c1b1a'
  on-tertiary-fixed-variant: '#484745'
  background: '#f9f9f9'
  on-background: '#1a1c1c'
  surface-variant: '#e2e2e2'
typography:
  display-lg:
    fontFamily: Playfair Display
    fontSize: 64px
    fontWeight: '700'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Playfair Display
    fontSize: 40px
    fontWeight: '700'
    lineHeight: '1.2'
  headline-lg:
    fontFamily: Playfair Display
    fontSize: 48px
    fontWeight: '600'
    lineHeight: '1.2'
  headline-lg-mobile:
    fontFamily: Playfair Display
    fontSize: 32px
    fontWeight: '600'
    lineHeight: '1.3'
  headline-md:
    fontFamily: Playfair Display
    fontSize: 32px
    fontWeight: '500'
    lineHeight: '1.3'
  body-lg:
    fontFamily: Montserrat
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
    letterSpacing: 0.01em
  body-md:
    fontFamily: Montserrat
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  label-caps:
    fontFamily: Montserrat
    fontSize: 12px
    fontWeight: '600'
    lineHeight: '1.0'
    letterSpacing: 0.15em
  button:
    fontFamily: Montserrat
    fontSize: 14px
    fontWeight: '500'
    lineHeight: '1.0'
    letterSpacing: 0.1em
spacing:
  unit: 8px
  container-max: 1280px
  gutter: 32px
  section-padding-desktop: 120px
  section-padding-mobile: 64px
  stack-sm: 16px
  stack-md: 32px
  stack-lg: 64px
---

## Brand & Style

The design system embodies the intersection of artisanal mastery and contemporary luxury. It is crafted for a dual audience: high-end clientele seeking bespoke grooming and ambitious professionals enrolling in an elite academy. 

The aesthetic is **Elevated Minimalism**. It relies on the tension between expansive white space and high-contrast, structured typography. The UI should feel like a high-fashion editorial magazine—quiet, confident, and intentional. Every element serves a purpose, avoiding unnecessary decoration to let the photography of hair artistry and architectural salon spaces take center stage. 

The emotional response should be one of "effortless prestige." By utilizing a restrained palette and generous negative space, the system conveys a sense of calm, cleanliness, and uncompromising quality.

## Colors

The color strategy is rooted in "Organic Sophistication," using earthy, tonal depths to create a premium feel without the clichés of gold leaf or black-and-gold combinations.

- **Background (Pure White):** Used as the primary canvas to ensure the layout feels airy and clinical yet inviting.
- **Primary (Dark Chocolate Brown):** Used for all headings, primary body text, and heavy structural elements. This provides a softer, more "couture" alternative to pure black.
- **Accent (Soft Mocha/Gold-tinged Brown):** Used for call-to-action buttons, active states, and interactive highlights. This color should be treated as a "signature" rather than a primary filler.
- **Subtle Surface (Soft Beige/Tertiary):** A very faint off-white used for subtle section separators or card backgrounds to maintain depth without breaking the minimalist flow.

## Typography

The typography pairings are designed to create a clear hierarchy between "The Art" (Headings) and "The Information" (Body).

- **Headlines (Playfair Display):** Should be set with tight leading and slight negative letter-spacing for large sizes to emphasize its editorial elegance. Use "Italic" styles sparingly for quotes or emphasis to add a touch of personality.
- **Body & Functional Text (Montserrat):** Chosen for its geometric clarity. Larger body text (body-lg) should be used for introductory paragraphs to maintain a premium feel. 
- **The "Label-Caps" Role:** This is essential for navigation and categorization. Always use uppercase with generous letter spacing (15%) to distinguish it from standard body text.

## Layout & Spacing

This design system utilizes a **Fixed Grid** approach for desktop to preserve the integrity of the white space, and a **Fluid Grid** for mobile.

- **Grid:** A 12-column grid with wide 32px gutters. Elements should often "breathe" by spanning fewer columns than available, creating asymmetrical interest.
- **Rhythm:** We use a base-8 spacing scale. However, the defining characteristic is "Extreme Padding." Sections should be separated by 120px on desktop to ensure the user never feels overwhelmed.
- **Margins:** Desktop margins are fixed at 80px minimum. Mobile margins are 24px.
- **Alignment:** Content should predominantly be left-aligned to maintain a modern, structured feel, though display headers can be centered for dramatic impact in the "Academy" sections.

## Elevation & Depth

To maintain a minimalist and clean aesthetic, this design system avoids heavy drop shadows. 

- **Tonal Layers:** Depth is achieved through the contrast of White (#FFFFFF) against the Soft Beige (#F9F5F2) tertiary color. Use these subtle shifts to define card areas or section breaks.
- **Low-Contrast Outlines:** For input fields and secondary buttons, use a 1px border in a very light version of the primary brown (approx. 10% opacity). This defines the shape without adding visual weight.
- **Imagery as Depth:** High-quality photography with shallow depth-of-field serves as the "3rd dimension." Backgrounds remain flat to allow the images to pop.
- **The "Hover" State:** Interactivity is signaled by color shifts (Mocha to Dark Brown) rather than physical elevation or shadow changes.

## Shapes

The shape language is **Strictly Geometric and Sharp**. 

- **Sharp Corners (0px):** All buttons, image containers, cards, and input fields must have 0px border radius. This "Sharp" aesthetic communicates precision, professionalism, and architectural luxury. 
- **Lines:** Use thin (1px) horizontal lines in the Accent color (#A67C52) to separate list items or label sections, reinforcing the editorial grid.
- **Image Treatment:** Images should always be rectangular or square. Avoid circles or organic masks.

## Components

- **Buttons:** 
  - *Primary:* Solid Soft Mocha (#A67C52) with White text. Sharp corners. Uppercase text with 0.1em spacing.
  - *Secondary:* Transparent with a 1px Dark Chocolate (#3E2723) border.
- **Input Fields:** Minimalist design with only a bottom border (1px) in Dark Chocolate. Labels should use the "label-caps" typography style positioned above the line.
- **Cards:** No borders or shadows. Cards are defined by their internal padding and a background of Soft Beige (#F9F5F2). Images within cards must be flush to the top and sides.
- **Academy Chips:** Small, rectangular tags using the Primary color with White "label-caps" text, used to categorize course levels (e.g., BEGINNER, MASTERCLASS).
- **Navigation:** Top-level navigation should be sparse. Use a centered logo with navigation links in "label-caps" split on either side or tucked into a clean "Menu" label.
- **Service Lists:** Use a classic "Menu" layout for salon services: Service name (Left), Price (Right), and a dotted or solid 1px line connecting them, set in Playfair Display.